# AWS-Microservice-with-CICD
 Implementation of a microservice along with CICD pipeline. Service used- CodeCommit, CodeBuild, CodePipeline, ECR, ECS, ALB, DynamoDB, VPC
